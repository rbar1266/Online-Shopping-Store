-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2026 at 10:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lumi_skin`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Slug` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_ID`, `Name`, `Slug`) VALUES
(1, 'Cleansers', 'cleansers'),
(2, 'Toners', 'toners'),
(3, 'Serums', 'serums'),
(4, 'Moisturizers', 'moisturizers'),
(5, 'Sun care', 'sun-care'),
(6, 'Masks & eyes', 'masks-eyes');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Order_ID` int(11) NOT NULL,
  `CustomerName` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` varchar(150) NOT NULL,
  `City` varchar(60) NOT NULL,
  `State` varchar(30) NOT NULL,
  `Zip` varchar(12) NOT NULL,
  `Subtotal` decimal(10,2) NOT NULL,
  `Shipping` decimal(10,2) NOT NULL,
  `Total` decimal(10,2) NOT NULL,
  `PaymentMethod` varchar(20) NOT NULL DEFAULT 'card',
  `CardLast4` char(4) NOT NULL DEFAULT '0000',
  `Status` enum('pending','paid','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Order_ID`, `CustomerName`, `Email`, `Address`, `City`, `State`, `Zip`, `Subtotal`, `Shipping`, `Total`, `PaymentMethod`, `CardLast4`, `Status`, `CreatedAt`) VALUES
(1, 'Name', 'Johndoe@gmail.com', '123 road', 'place', 'state', '12345', 28.00, 4.95, 32.95, 'card', '0000', 'pending', '2026-11-11 04:50:06'),
(2, 'name', 'demo@email.com', 'fake Street', 'fakeland', 'fakeplace', '12345', 32.00, 4.95, 36.95, 'card', '0000', 'paid', '2026-11-11 20:27:25');

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `Item_ID` int(11) NOT NULL,
  `Order_ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `UnitPrice` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`Item_ID`, `Order_ID`, `Product_ID`, `ProductName`, `Quantity`, `UnitPrice`) VALUES
(1, 1, 4, 'Vitamin C Serum', 1, 28.00),
(2, 2, 3, 'Rose Water Toner', 1, 13.00),
(3, 2, 10, 'Daily Fluid SPF 50', 1, 19.00);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_ID` int(11) NOT NULL,
  `Category_ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(255) NOT NULL DEFAULT '',
  `SkinType` varchar(50) NOT NULL DEFAULT 'All skin types',
  `Size` varchar(20) NOT NULL DEFAULT '',
  `Price` decimal(10,2) NOT NULL,
  `StockQty` int(11) NOT NULL DEFAULT 0,
  `Image` varchar(200) NOT NULL,
  `IsFeatured` tinyint(1) NOT NULL DEFAULT 0,
  `IsActive` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_ID`, `Category_ID`, `Name`, `Description`, `SkinType`, `Size`, `Price`, `StockQty`, `Image`, `IsFeatured`, `IsActive`) VALUES
(1, 1, 'Gentle Gel Cleanser', 'Lightweight foaming gel that lifts oil and sunscreen without tightness.', 'Oily, combination', '150 ml', 14.00, 50, 'images/cleanser.svg', 0, 1),
(2, 1, 'Oat Milk Cleanser', 'Creamy, fragrance-free cleanser that soothes while it cleans.', 'Dry, sensitive', '150 ml', 16.00, 50, 'images/oat-cleanser.svg', 0, 1),
(3, 2, 'Rose Water Toner', 'Alcohol-free mist that rebalances skin after cleansing.', 'All skin types', '200 ml', 13.00, 50, 'images/rose-toner.svg', 0, 1),
(4, 3, 'Vitamin C Serum', '10% vitamin C to brighten dull skin and fade dark spots.', 'Normal, combination', '30 ml', 28.00, 50, 'images/vitamin-c.svg', 1, 1),
(5, 3, 'Hyaluronic Acid Serum', 'Multi-weight hyaluronic acid for plump, hydrated skin.', 'All skin types', '30 ml', 24.00, 50, 'images/hyaluronic.svg', 1, 1),
(6, 3, 'Niacinamide 10% Serum', 'Helps minimize the look of pores and balance oil.', 'Oily, blemish-prone', '30 ml', 18.00, 50, 'images/niacinamide.svg', 0, 1),
(7, 3, 'Retinol Night Serum', '0.3% retinol for smoother texture. Use at night only.', 'Normal, mature', '30 ml', 32.00, 50, 'images/retinol.svg', 0, 1),
(8, 4, 'Daily Gel Cream', 'Oil-free gel moisturizer that absorbs in seconds.', 'Oily, combination', '50 ml', 22.00, 50, 'images/gel-cream.svg', 1, 1),
(9, 4, 'Ceramide Barrier Cream', 'Rich cream with ceramides to repair a dry, stressed barrier.', 'Dry, sensitive', '50 ml', 26.00, 50, 'images/ceramide.svg', 0, 1),
(10, 5, 'Daily Fluid SPF 50', 'Invisible broad-spectrum sunscreen, no white cast.', 'All skin types', '50 ml', 19.00, 50, 'images/spf.svg', 1, 1),
(11, 6, 'Clay Purifying Mask', 'Kaolin clay mask that clears congestion in 10 minutes.', 'Oily, combination', '75 ml', 17.00, 0, 'images/clay-mask.svg', 0, 1),
(12, 6, 'Caffeine Eye Cream', 'Depuffs and brightens the delicate under-eye area.', 'All skin types', '15 ml', 21.00, 50, 'images/eye-cream.svg', 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_ID`),
  ADD UNIQUE KEY `Slug` (`Slug`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Order_ID`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`Item_ID`),
  ADD KEY `Order_ID` (`Order_ID`),
  ADD KEY `Product_ID` (`Product_ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_ID`),
  ADD KEY `Category_ID` (`Category_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Category_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `Order_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `Item_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Product_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_item`
--
ALTER TABLE `order_item`
  ADD CONSTRAINT `order_item_ibfk_1` FOREIGN KEY (`Order_ID`) REFERENCES `orders` (`Order_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`Product_ID`) REFERENCES `product` (`Product_ID`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`Category_ID`) REFERENCES `category` (`Category_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
