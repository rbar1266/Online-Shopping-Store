<?php require_once 'config.php';
$items = cart_items($pdo);
if (!$items) { header('Location: cart.php'); exit; }
[$sub, $ship, $total] = cart_totals($items);
const DEMO_CARD = '0000-0000-0000-0000';  // dummy card, never a real one
$errors = []; $f = ['name'=>'','email'=>'','address'=>'','city'=>'','state'=>'','zip'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($f as $k => $_) $f[$k] = trim($_POST[$k] ?? '');
    foreach ($f as $k => $v) if ($v === '') $errors[] = "Please fill in your $k.";
    if ($f['email'] !== '' && !filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';

    if (!$errors) {
        try {
            $pdo->beginTransaction();
            foreach ($items as $p) {   // lock rows and re-check stock
                $st = $pdo->prepare("SELECT StockQty FROM product WHERE Product_ID = ? FOR UPDATE");
                $st->execute([$p['Product_ID']]);
                if ($st->fetchColumn() < $p['Qty']) throw new RuntimeException($p['Name'] . ' no longer has enough stock.');
            }
            $pdo->prepare("INSERT INTO orders (CustomerName, Email, Address, City, State, Zip, Subtotal, Shipping, Total, PaymentMethod, CardLast4, Status) VALUES (?,?,?,?,?,?,?,?,?,'card',?,'paid')")
                ->execute([$f['name'], $f['email'], $f['address'], $f['city'], $f['state'], $f['zip'], $sub, $ship, $total, substr(DEMO_CARD, -4)]);
            $oid = (int)$pdo->lastInsertId();
            $ins = $pdo->prepare("INSERT INTO order_item (Order_ID, Product_ID, ProductName, Quantity, UnitPrice) VALUES (?,?,?,?,?)");
            $dec = $pdo->prepare("UPDATE product SET StockQty = StockQty - ? WHERE Product_ID = ?");
            foreach ($items as $p) {
                $ins->execute([$oid, $p['Product_ID'], $p['Name'], $p['Qty'], $p['Price']]);
                $dec->execute([$p['Qty'], $p['Product_ID']]);
            }
            $pdo->commit();
            $_SESSION['cart'] = [];
            $_SESSION['last_order'] = $oid;
            header('Location: success.php'); exit;
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $errors[] = $ex instanceof RuntimeException ? $ex->getMessage() : 'Something went wrong placing your order. Please try again.';
        }
    }
}
$title = 'Checkout'; include 'header.php'; ?>
<section class="wrap checkout">
    <form method="post" class="form">
        <h1>Checkout</h1>
        <?php foreach ($errors as $er): ?><p class="error"><?= e($er) ?></p><?php endforeach; ?>
        <label>Full name <input name="name" value="<?= e($f['name']) ?>"></label>
        <label>Email <input name="email" type="email" value="<?= e($f['email']) ?>"></label>
        <label>Street address <input name="address" value="<?= e($f['address']) ?>"></label>
        <div class="row">
            <label>City <input name="city" value="<?= e($f['city']) ?>"></label>
            <label>State <input name="state" value="<?= e($f['state']) ?>"></label>
            <label>ZIP <input name="zip" value="<?= e($f['zip']) ?>"></label>
        </div>
        <fieldset class="pay">
            <legend>Payment</legend>
            <p class="muted">Demo card. It is filled in for you and no real card is used or stored.</p>
            <label>Card number <input value="<?= e(DEMO_CARD) ?>" readonly></label>
            <div class="row2">
                <label>Name on card <input value="Demo Customer" readonly></label>
                <label>Expiry <input value="12/30" readonly></label>
                <label>CVC <input value="000" readonly></label>
            </div>
        </fieldset>
        <button class="btn">Place order &middot; <?= money($total) ?></button>
    </form>
    <aside class="summary">
        <h2>Order summary</h2>
        <?php foreach ($items as $p): ?><p><?= (int)$p['Qty'] ?> &times; <?= e($p['Name']) ?> <b><?= money($p['Line']) ?></b></p><?php endforeach; ?>
        <p>Shipping <b><?= $ship ? money($ship) : 'Free' ?></b></p>
        <p class="grand">Total <b><?= money($total) ?></b></p>
    </aside>
</section>
<?php include 'footer.php'; ?>
