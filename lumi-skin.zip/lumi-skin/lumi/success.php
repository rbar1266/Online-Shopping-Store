<?php $title = 'Order placed'; include 'header.php';
$id = (int)($_SESSION['last_order'] ?? 0);
$st = $pdo->prepare("SELECT * FROM orders WHERE Order_ID = ?"); $st->execute([$id]); $o = $st->fetch();
if (!$o) { header('Location: shop.php'); exit; }
$st = $pdo->prepare("SELECT * FROM order_item WHERE Order_ID = ?"); $st->execute([$id]); $lines = $st->fetchAll(); ?>
<section class="wrap narrow">
    <h1>Thank you, <?= e($o['CustomerName']) ?>.</h1>
    <p>Order #<?= (int)$o['Order_ID'] ?> is placed. A confirmation would go to <?= e($o['Email']) ?>.</p>
    <div class="summary">
        <?php foreach ($lines as $l): ?><p><?= (int)$l['Quantity'] ?> &times; <?= e($l['ProductName']) ?> <b><?= money($l['Quantity'] * $l['UnitPrice']) ?></b></p><?php endforeach; ?>
        <p>Shipping <b><?= $o['Shipping'] > 0 ? money($o['Shipping']) : 'Free' ?></b></p>
        <p class="grand">Total <b><?= money($o['Total']) ?></b></p>
        <p class="muted">Paid with card ending in <?= e($o['CardLast4']) ?></p>
        <p class="muted">Shipping to <?= e($o['Address']) ?>, <?= e($o['City']) ?>, <?= e($o['State']) ?> <?= e($o['Zip']) ?></p>
    </div>
    <a class="btn" href="shop.php">Keep shopping</a>
</section>
<?php include 'footer.php'; ?>
