</main>
<footer class="foot">
    <p>Lumi Skin &middot; Free shipping on orders over <?= money(FREE_SHIPPING_OVER) ?></p>
    <p class="muted">Demo store. No real payments are taken.</p>
</footer>
</body>
</html>
