
1. Start Apache + MySQL in XAMPP and copy this folder to `htdocs/lumi`.
2. In phpMyAdmin, import `database.sql` (creates the `lumi_skin` database).
4. Open http://localhost/lumi-skin/lumi/index.php
Product images are placeholder SVGs in `images/`
Aka computer genorated, I could replace them if asked please tell me. to do it yourseld replace them and update the `Image` column if you want, I am very lazy lol

Also tell me if you can't open the file following these intstutions 