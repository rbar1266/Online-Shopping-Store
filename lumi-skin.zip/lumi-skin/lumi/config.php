<?php
session_start();
$pdo = new PDO('mysql:host=127.0.0.1;dbname=lumi_skin;charset=utf8mb4', 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
const FREE_SHIPPING_OVER = 40.00;
const SHIPPING_FEE = 4.95;

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($n) { return '$' . number_format((float)$n, 2); }
function cart_count() { return array_sum($_SESSION['cart'] ?? []); }
function cart_items(PDO $pdo) {
    $cart = $_SESSION['cart'] ?? [];
    if (!$cart) return [];
    $ids = array_keys($cart);
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT * FROM product WHERE Product_ID IN ($in) AND IsActive = 1");
    $st->execute($ids);
    $rows = [];
    foreach ($st as $p) {
        $p['Qty'] = min($cart[$p['Product_ID']], max(1, $p['StockQty']));
        $p['Line'] = $p['Qty'] * $p['Price'];
        $rows[] = $p;
    }
    return $rows;
}
function cart_totals(array $items) {
    $sub = array_sum(array_column($items, 'Line'));
    $ship = ($sub == 0 || $sub >= FREE_SHIPPING_OVER) ? 0 : SHIPPING_FEE;
    return [$sub, $ship, $sub + $ship];
}
function product_card(array $p) { ?>
    <article class="card">
        <img src="<?= e($p['Image']) ?>" alt="<?= e($p['Name']) ?>">
        <div class="card-body">
            <h3><?= e($p['Name']) ?></h3>
            <p class="muted"><?= e($p['Size']) ?> &middot; <?= e($p['SkinType']) ?></p>
            <p class="desc"><?= e($p['Description']) ?></p>
            <form method="post" action="cart.php" class="buy">
                <span class="price"><?= money($p['Price']) ?></span>
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="id" value="<?= (int)$p['Product_ID'] ?>">
                <?php if ($p['StockQty'] > 0): ?>
                    <button class="btn">Add to bag</button>
                <?php else: ?>
                    <button class="btn" disabled>Sold out</button>
                <?php endif; ?>
            </form>
        </div>
    </article>
<?php }
