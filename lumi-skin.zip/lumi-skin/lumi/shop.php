<?php $title = 'Shop'; include 'header.php';
$cats = $pdo->query("SELECT * FROM category ORDER BY Category_ID")->fetchAll();
$slug = $_GET['cat'] ?? '';
if ($slug !== '') {
    $st = $pdo->prepare("SELECT p.* FROM product p JOIN category c USING (Category_ID) WHERE p.IsActive = 1 AND c.Slug = ? ORDER BY p.Name");
    $st->execute([$slug]);
} else {
    $st = $pdo->query("SELECT * FROM product WHERE IsActive = 1 ORDER BY Category_ID, Name");
}
$products = $st->fetchAll(); ?>
<section class="wrap">
    <h1>Shop</h1>
    <div class="filters">
        <a href="shop.php" class="<?= $slug === '' ? 'on' : '' ?>">All</a>
        <?php foreach ($cats as $c): ?>
            <a href="shop.php?cat=<?= e($c['Slug']) ?>" class="<?= $slug === $c['Slug'] ? 'on' : '' ?>"><?= e($c['Name']) ?></a>
        <?php endforeach; ?>
    </div>
    <?php if (!$products): ?><p>No products in this category yet.</p><?php endif; ?>
    <div class="grid"><?php foreach ($products as $p) product_card($p); ?></div>
</section>
<?php include 'footer.php'; ?>
