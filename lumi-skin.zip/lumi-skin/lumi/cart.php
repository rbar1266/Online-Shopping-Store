<?php require_once 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $act = $_POST['action'] ?? '';
    if ($act === 'add') {
        $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
    } elseif ($act === 'update') {
        $q = (int)($_POST['qty'] ?? 1);
        if ($q < 1) unset($_SESSION['cart'][$id]); else $_SESSION['cart'][$id] = min($q, 20);
    } elseif ($act === 'remove') {
        unset($_SESSION['cart'][$id]);
    }
    header('Location: ' . ($act === 'add' ? ($_SERVER['HTTP_REFERER'] ?? 'shop.php') : 'cart.php'));
    exit;
}
$title = 'Your bag'; include 'header.php';
$items = cart_items($pdo);
[$sub, $ship, $total] = cart_totals($items); ?>
<section class="wrap">
    <h1>Your bag</h1>
    <?php if (!$items): ?>
        <p>Your bag is empty.</p><a class="btn" href="shop.php">Browse products</a>
    <?php else: ?>
        <table class="bag-table">
            <?php foreach ($items as $p): ?>
            <tr>
                <td><img src="<?= e($p['Image']) ?>" alt="" width="64"></td>
                <td><strong><?= e($p['Name']) ?></strong><br><span class="muted"><?= money($p['Price']) ?> each</span></td>
                <td>
                    <form method="post" class="inline">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="id" value="<?= (int)$p['Product_ID'] ?>">
                        <input type="number" name="qty" value="<?= (int)$p['Qty'] ?>" min="0" max="20" aria-label="Quantity">
                        <button class="link">Update</button>
                    </form>
                </td>
                <td><?= money($p['Line']) ?></td>
                <td>
                    <form method="post"><input type="hidden" name="action" value="remove">
                    <input type="hidden" name="id" value="<?= (int)$p['Product_ID'] ?>"><button class="link">Remove</button></form>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <div class="summary">
            <p>Subtotal <b><?= money($sub) ?></b></p>
            <p>Shipping <b><?= $ship ? money($ship) : 'Free' ?></b></p>
            <p class="grand">Total <b><?= money($total) ?></b></p>
            <a class="btn" href="checkout.php">Go to checkout</a>
        </div>
    <?php endif; ?>
</section>
<?php include 'footer.php'; ?>
