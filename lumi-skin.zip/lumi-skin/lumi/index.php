<?php $title = 'Home'; include 'header.php';
$featured = $pdo->query("SELECT * FROM product WHERE IsFeatured = 1 AND IsActive = 1 LIMIT 4")->fetchAll(); ?>
<section class="hero">
    <div>
        <h1>Skincare that keeps it simple.</h1>
        <p>Twelve well-made essentials. Cleanse, treat, moisturize, protect.</p>
        <a class="btn" href="shop.php">Shop all products</a>
    </div>
    <div class="hero-art">
        <img src="images/vitamin-c.svg" alt="">
        <img src="images/gel-cream.svg" alt="">
        <img src="images/spf.svg" alt="">
    </div>
</section>
<section class="wrap">
    <h2>Most-loved</h2>
    <div class="grid"><?php foreach ($featured as $p) product_card($p); ?></div>
</section>
<?php include 'footer.php'; ?>
